



	The "fonts.conf" file is used by "Libass" and initially refers to the
	Windows font directory.

	If you have fonts at other locations that you want to make available
	for the Avanti subtitle burn-in option, you can add these as follows.
	
	Open the "fonts.conf" file in a text editor like "NotePad" and add the
	full path to your fonts at this section ...


	<!-- Font directory list -->

		<dir>WINDOWSFONTDIR</dir>
	
		<dir>~/.fonts</dir>

		<dir>Full_path_to_your_fonts</dir>
	<!--


	Ensure that you do not corrupt any other data in the "fonts.conf" file.


