


	AVANTI - Version 0.9.2 - FFmpeg/AviSynth GUI
	============================================


	Most FFmpeg Win32 builds include a folder named "share" or "presets"
	from where you can copy a few predefined libx264 and libvpx presets
	to this folder.

	Avanti supports the use of FFmpeg presets. For more details, read the
	"FFmpeg presets" section in the "Avanti-help.chm".

	The two already included presets are used in a example template.

 
	April 2015 - Chris Kevany

	