


	You can copy frei0r plugin dll's to this folder. This location is set
	in the "environment_vars.ini" file at the "/ffmpeg" folder.
	
	What is Frei0r ...

	Frei0r is a minimalistic plugin API for video effects. The main emphasis
	is on simplicity for an API that will round up the most common video effects
	into simple filters, sources and mixers that can be controlled by parameters.
	It�s our hope that this way these simple effects can be shared between many
	applications, avoiding their reimplementation by different projects.

	http://www.dyne.org/software/frei0r/

	You can download Windows builds of these plugins at ...

	http://oss.netfarm.it/mplayer-win32.php



	
